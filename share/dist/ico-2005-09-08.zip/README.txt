I used a remote icon because phpclasses wouldn't let me upload the file.
It gets slow when you run the tests so please download the ico and change the
test scripts or use your icons ;)

There's no documentation, the classes are simple. Open the source and look to
the comments.