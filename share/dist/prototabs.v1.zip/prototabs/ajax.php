<?
	print "this is your var: " . $_GET['var'];
	exit();
?>
you should have a server side script to do ajax.