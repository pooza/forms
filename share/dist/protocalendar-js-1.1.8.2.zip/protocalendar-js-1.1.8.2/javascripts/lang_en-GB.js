(function() {
   ProtoCalendar.LangFile['en-GB'] = Object.extend(ProtoCalendar.LangFile['en'], { });
 })();
